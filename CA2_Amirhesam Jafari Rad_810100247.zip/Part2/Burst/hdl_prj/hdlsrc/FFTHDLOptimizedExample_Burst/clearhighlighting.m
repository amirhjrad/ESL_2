SLStudio.Utils.RemoveHighlighting(get_param('FFTHDLOptimizedExample_Burst', 'handle'));
SLStudio.Utils.RemoveHighlighting(get_param('gm_FFTHDLOptimizedExample_Burst', 'handle'));
annotate_port('gm_FFTHDLOptimizedExample_Burst/FFT Burst/FFT', 0, 1, '');
