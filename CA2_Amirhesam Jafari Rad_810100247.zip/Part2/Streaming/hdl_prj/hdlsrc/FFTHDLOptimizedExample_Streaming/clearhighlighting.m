SLStudio.Utils.RemoveHighlighting(get_param('FFTHDLOptimizedExample_Streaming', 'handle'));
SLStudio.Utils.RemoveHighlighting(get_param('gm_FFTHDLOptimizedExample_Streaming', 'handle'));
annotate_port('gm_FFTHDLOptimizedExample_Streaming/FFT Streaming/FFT', 0, 1, '');
